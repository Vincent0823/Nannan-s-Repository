from django import forms
from django.core.exceptions import ValidationError
import re
from .models import *
import sys
sys.path.append("..")
from Person.models import *


# 用户详细信息表单
class User_Detail_Form(forms.ModelForm):
    class Meta:
        model = Person
        fields = ['sex', 'birthday', 'country', 'registered_region', 'registered_detail',
                  'permanent_region', 'permanent_detail', 'job', 'company', 'tel', 'medical_history'
                  ]

        widgets = {
            'birthday': forms.DateInput(attrs={'type': 'date'})
        }

        error_messages = {
            '__all__': {'required': '请输入内容',
                        'invalid': '请检查输入内容'
                        },
        }


class Health_Form(forms.ModelForm):

    class Meta:
        model = Health
        fields = ['temperature', 'symptom', 'symptoms', 'risk', 'risk_sojourn', 'contact', 'risk_contact', ]
        widgets = {
            'temperature': forms.TextInput(attrs={'class': 'c1'}),
            'symptoms': forms.TextInput(attrs={'class': 'form-control'}),
            'risk_sojourn': forms.TextInput(attrs={'class': 'form-control'}),
            'risk_contact': forms.TextInput(attrs={'class': 'form-control'}),
        }

        help_texts = {
            'temperature': "°C"
        }

    def __init__(self, *args, **kwargs):
        super(Health_Form, self).__init__(*args, **kwargs)
        self.fields['symptom'].required = False
        self.fields['symptoms'].required = False
        self.fields['risk'].required = False
        self.fields['risk_sojourn'].required = False
        self.fields['contact'].required = False
        self.fields['risk_contact'].required = False


def temperature_validate(value):
    if 35 <= float(value) <= 42:
        return value
    else:
        raise ValueError('请输入正确的温度')
