import xadmin
from xadmin import views
from .models import *


# 设置IdType的Admin
class IdTypeAdmin(object):
    list_display = ['id', 'type']
    list_filter = ['id', 'type']
    search_fields = ['type']
    ordering = ['id']


xadmin.site.register(IdType, IdTypeAdmin)


# # 设置Sex的Admin
# class SexAdmin(object):
#     list_display = ['id', 'type']
#


# 设置用户的Admin
class PersonAdmin(object):
    list_display = ['id', 'name', 'sex', 'country',
                    'registered_region', 'permanent_region']
    list_filter = ['country', 'registered_region', 'permanent_region']


xadmin.site.register(Person, PersonAdmin)

