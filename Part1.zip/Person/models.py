from django.db import models
import sys
import datetime
sys.path.append('..')
from Common.models import *


# 证件类型表
class IdType(models.Model):
    id = models.CharField(max_length=20, verbose_name="证件代号", primary_key=True)
    type = models.CharField(max_length=30, verbose_name="证件类型")

    def __str__(self):
        return self.type

    class Meta:
        verbose_name = '证件类型'
        verbose_name_plural = '证件类型'


# 性别表
class Sex(models.Model):
    id = models.IntegerField(verbose_name="编号", primary_key=True)
    type = models.CharField(max_length=2, verbose_name="性别")

    def __str__(self):
        return self.type

    class Meta:
        verbose_name = '性别'
        verbose_name_plural = '性别'


# 核酸检测结果类型
class NAT_result(models.Model):
    type = models.CharField(max_length=4, verbose_name='核酸检测结果')

    def __str__(self):
        return self.type

    class Meta:
        verbose_name = '核酸检测结果类型'
        verbose_name_plural = '核酸检测结果类型'


# 异常状态原因
class Abnormal_Causes(models.Model):
    id = models.CharField(max_length=4, verbose_name="异常原因编码", primary_key=True)
    reason = models.CharField(max_length=100, verbose_name="异常原因")
    duration_time = models.IntegerField(verbose_name="异常持续时间")

    def __str__(self):
        return self.reason

    class Meta:
        verbose_name = '健康码状态异常原因'
        verbose_name_plural = '健康码状态异常原因'


# 健康码类型
class Health_Code_Type(models.Model):
    id = models.CharField(max_length=2, verbose_name="状态编码", primary_key=True)
    H_type = models.CharField(max_length=4, verbose_name="状态名称")

    def __str__(self):
        return self.H_type

    class Meta:
        verbose_name = '健康码类型'
        verbose_name_plural = '健康码类型'


# 用户表
class Person(models.Model):
    system_id = models.ForeignKey(User, verbose_name="系统编号", on_delete=models.PROTECT)

    # 基本信息
    id_type = models.ForeignKey(IdType, verbose_name='证件类型', on_delete=models.PROTECT)
    id = models.CharField(max_length=20, verbose_name='证件号码', primary_key=True)
    name = models.CharField(max_length=50, verbose_name='姓名')
    sex = models.ForeignKey(Sex, on_delete=models.CASCADE, verbose_name='性别')
    age = models.PositiveIntegerField(verbose_name='年龄')
    birthday = models.DateField(verbose_name='出生日期')

    # 户籍信息
    country = models.ForeignKey(Country, verbose_name='国籍', on_delete=models.PROTECT)
    registered_region = models.ForeignKey(Region, verbose_name='户籍所在区划',
                                          related_name="registered_region", on_delete=models.PROTECT, null=True)
    registered_detail = models.CharField(max_length=200, verbose_name='户籍所在详细地址', null=True)

    # 常住信息
    permanent_region = models.ForeignKey(Region, verbose_name='常住地址所在区划',
                                         related_name="permanent_region", on_delete=models.PROTECT, null=True)
    permanent_detail = models.CharField(max_length=200, verbose_name='常住地内详细地址', null=True)

    # 详细信息
    job = models.CharField(max_length=20, verbose_name='职业')
    company = models.CharField(max_length=40, verbose_name='公司', null=True)
    tel = models.CharField(max_length=11, verbose_name='联系电话')
    medical_history = models.CharField(max_length=255, verbose_name='基础病史')

    # 创建一个个人用户
    """
    e.g:
    python manage.py shell
    from Person.models import *
    Person.create_non_active_user(Person, '35060220000408251X', '123456', 'ARMYMANCARD', 'wwj', 2000, 4, 8, 21, 1, 'CHN')
    """
    def create_non_active_user(self, id_num, password, id_type, name, year, month, day, age, sex, country,
                               registered_city=-1, registered_detail='无', permanent_city=-1, permanent_detail='无',
                               is_active=False):
        User.objects.create_user(username=id_num, password=password, is_active=is_active)
        system_id = User.objects.get(username=id_num).id
        self.objects.create(system_id_id=system_id, id=id_num, name=name, birthday=datetime.date(year, month, day),
                            age=age, sex_id=sex, id_type_id=id_type, country_id=country,
                            registered_region_id=registered_city, registered_detail=registered_detail,
                            permanent_region_id=permanent_city, permanent_detail=permanent_detail)

    def __str__(self):
        return self.id

    class Meta:
        verbose_name = '基本用户信息'
        verbose_name_plural = '基本用户信息'


# 乘坐表
class Board(models.Model):
    id_num = models.ForeignKey(Person, on_delete=models.PROTECT, verbose_name='证件号码')
    no = models.ForeignKey(Schedule, on_delete=models.PROTECT, verbose_name='班次')
    date = models.DateField(verbose_name="出发日期")
    seat = models.CharField(max_length=15, verbose_name='座位号')
    start_no = models.CharField(max_length=3, verbose_name='起始站点号')
    end_no = models.CharField(max_length=3, verbose_name='目的站点号')

    def __str__(self):
        return "-".join([str(self.id_num), str(self.date), str(self.no)])

    class Meta:
        verbose_name = '乘坐信息'
        verbose_name_plural = '乘坐信息'


# 健康打卡信息
class Health(models.Model):
    id_num = models.ForeignKey(Person, on_delete=models.PROTECT, verbose_name='证件号码')
    datetime = models.DateTimeField(verbose_name='打卡时间')
    temperature = models.CharField(max_length=5, verbose_name='体温')
    symptom = models.BooleanField(verbose_name='是否有不良症状')
    symptoms = models.CharField(max_length=200, verbose_name='当前症状', null=True)
    risk = models.BooleanField(verbose_name='近14天是否有境外(或其他中高风险地区)旅居史')
    risk_sojourn = models.CharField(max_length=200, verbose_name='中高风险地区居住和停留情况', null=True)
    contact = models.BooleanField(verbose_name='是否有新冠肺炎接触情况')
    risk_contact = models.CharField(max_length=200, verbose_name='高风险人员接触情况', null=True)

    def __str__(self):
        return "-".join([str(self.id_num), str(self.datetime)])

    class Meta:
        verbose_name = '健康打卡信息'
        verbose_name_plural = '健康打卡信息'


# 行程信息
class Trace(models.Model):
    class Meta:
        unique_together = (("id_num", "datetime", "source"),)
        verbose_name = '行程信息'
        verbose_name_plural = '行程信息'

    id_num = models.ForeignKey(Person, on_delete=models.CASCADE, verbose_name='证件号码')
    region = models.ForeignKey(Region, verbose_name='地区', related_name="trace_region", on_delete=models.PROTECT)
    position = models.CharField(max_length=200, verbose_name='具体位置')
    datetime = models.DateTimeField(verbose_name='当前时间')
    source_type = models.ForeignKey(SourceType, verbose_name='信息来源类型', on_delete=models.PROTECT)
    source = models.CharField(max_length=40, verbose_name='信息来源')

    def __str__(self):
        return '-'.join([str(self.id_num), str(self.datetime)])


# 健康码信息
class Health_Code(models.Model):
    id_num = models.ForeignKey(Person, on_delete=models.PROTECT, verbose_name='证件号码')
    status = models.ForeignKey(Health_Code_Type, verbose_name='健康码状态', on_delete=models.PROTECT)
    datetime = models.DateTimeField(verbose_name='评估时间')
    reason = models.ForeignKey(Abnormal_Causes, verbose_name='异常状态原因', on_delete=models.PROTECT)

    def __str__(self):
        return "-".join([str(self.id_num), str(self.status), str(self.datetime)])

    class Meta:
        verbose_name = '健康码信息'
        verbose_name_plural = '健康码信息'


# 核酸检测信息
class NAT(models.Model):
    id_num = models.ForeignKey(Person, on_delete=models.CASCADE, verbose_name='证件号码')
    result = models.ForeignKey(NAT_result, verbose_name='核酸检测结果', on_delete=models.PROTECT)
    datetime = models.DateTimeField(verbose_name='检测时间')

    def __str__(self):
        return "-".join([str(self.id_num), str(self.result)])

    class Meta:
        verbose_name = '核酸检测信息'
        verbose_name_plural = '核酸检测信息'
