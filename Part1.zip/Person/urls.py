import sys
sys.path.append("..")
from django.urls import path
from .views import *
from .login import *

urlpatterns = [
    path('login.html', loginView, name='login'),
    path('register.html', registerView, name='register'),
    path('setpassword.html', setpasswordView, name='setpassword'),
    path('logout.html', logoutView, name='logout'),
    path('index.html', show_index),
    path('Appointment_Loaction.html', appointment_location),
    path('Appointment_Time.html', appointment_time),
    path('health_punch.html', health_punch),
    path('Isolate_report.html', isolate_report),
    path('isolate_search.html', isolate_search),
    path('logout', logoutView),
    path('index/logout', logoutView),
    path('index/', show_index),
    path('report_success.html', report_success)
]