from django.http import HttpResponse
from django.shortcuts import render, redirect
from django.contrib import admin
from django.contrib.auth import login, logout, authenticate
from django.contrib.auth.hashers import make_password
import sys
sys.path.append("..")
from Common.models import User
from .form import *


def loginView(request):
    # 设置标题和另外两个URL链接
    title = '登录'
    unit_2 = '/user/register.html'
    unit_2_name = '立即注册'
    unit_1 = '/user/setpassword.html'
    unit_1_name = '修改密码'
    tips = None
    if request.method == 'POST':
        username = request.POST.get('username', '')
        password = request.POST.get('password', '')
        if User.objects.filter(username=username):
            if User.objects.get(username=username).is_active:
                user = authenticate(username=username, password=password)
                if user:
                    login(request, user)
                    return redirect('/user/index/')
                else:
                    tips = '账号密码错误，请重新输入'
            else:
                tips = '账号还未注册，请激活后使用'
        else:
            tips = '用户不存在，请注册'
    return render(request, 'user.html', locals())


# 用户注册
def registerView(request):
    # 设置标题和另外两个URL链接
    title = '注册'
    unit_2 = '/user/login.html'
    unit_2_name = '立即登录'
    unit_1 = '/user/setpassword.html'
    unit_1_name = '修改密码'
    tips = None
    confirm_password = True
    detail_form = User_Detail_Form
    if request.method == 'POST':
        username = request.POST.get('username', '')
        password = request.POST.get('password', '')
        confirm_password = request.POST.get('confirm_password', '')
        if User.objects.filter(username=username):
            if not User.objects.get(username=username).is_active:
                if confirm_password != password:
                    tips = '密码不一致'
                else:
                    # user = User.objects.create_user(username=username, password=password)
                    # user.save()
                    # person = Person.objects.create()
                    # person.save()
                    p = Person.objects.get(id=username)
                    p.sex_id = request.POST.get('sex', '')
                    p.birthday = request.POST.get('birthday', '')
                    p.country_id = request.POST.get('country', '')
                    p.registered_region_id = request.POST.get('registered_region', '')
                    p.registered_detail = request.POST.get('registered_detail', '')
                    p.permanent_region_id = request.POST.get('permanent_region', '')
                    p.permanent_detail = request.POST.get('permanent_detail', '')
                    p.job = request.POST.get('job', '')
                    p.company = request.POST.get('company', '')
                    p.medical_history = request.POST.get('medical_history', '')
                    p.save()

                    user = User.objects.get(username=username)
                    user.password = make_password(password)
                    user.is_active = True
                    user.save()

                    return redirect('/login.html')
            else:
                tips = '该账号已注册'
        else:
            tips = '用户不存在'
    return render(request, 'user.html', locals())


# 修改密码
def setpasswordView(request):
    # 设置标题和另外两个URL链接
    title = '修改密码'
    unit_2 = '/user/login.html'
    unit_2_name = '立即登录'
    unit_1 = '/user/register.html'
    unit_1_name = '立即注册'
    tips = None
    new_password = True
    new_password_confirm = True
    if request.method == 'POST':
        username = request.POST.get('username', '')
        old_password = request.POST.get('password', '')
        new_password = request.POST.get('new_password', '')
        new_password_confirm = request.POST.get('new_password_confirm', '')
        if User.objects.filter(username=username):
            user = authenticate(username=username, password=old_password)
            # 判断用户的账号密码是否正确
            if old_password != new_password:
                if new_password == new_password_confirm:
                    if user:
                        user.set_password(new_password)
                        user.save()
                        tips = '密码修改成功'
                    else:
                        tips = '原始密码不正确'
                else:
                    tips = '密码不一致！'
            else:
                tips = '新密码与原密码相同'
        else:
            tips = '用户不存在'
    return render(request, 'user.html', locals())


# 使用make_password实现密码修改
def setpasswordView_1(request):
    tips = None
    if request.method == 'POST':
        username = request.POST.get('username', '')
        old_password = request.POST.get('password', '')
        new_password = request.POST.get('new_password', '')
        # 判断用户是否存在
        user = User.objects.filter(username=username)
        if User.objects.filter(username=username):
            user = authenticate(username=username, password=old_password)
            # 判断用户的账号密码是否正确
            if user:
                # 密码加密处理并保存到数据库
                dj_ps = make_password(new_password, None, 'pbkdf2_sha256')
                user.password = dj_ps
                user.save()
            else:
                print('原始密码不正确')
    return render(request, 'user.html', locals())


# 用户注销，退出登录
def logoutView(request):
    logout(request)
    return redirect('/')
