from django.shortcuts import render, HttpResponse
from django.utils import timezone

from .form import *
from .models import Person
# Create your views here.


def homepage(request):
    return render(request, 'home_page.html')


def show_index(request):
    # username = request.user.username
    # print(username)
    # name = Person.objects.get(id=username).name
    # name = '*' + name[1:]
    return render(request, 'index.html', locals())


def appointment_location(request):
    return render(request, 'Appointment_Loaction.html', locals())


def health_punch(request):
    global temperature
    health_form = Health_Form
    username = request.user.username
    id_num = Person.objects.get(id=username).id

    # 网页初始化
    if request.method == 'GET':
        tips = None
        # 如果今天已经打过卡了
        h = Health.objects.order_by('-datetime')
        if h:
            if h[0].datetime.date() == timezone.now().date():
                tips = '您已完成今日打卡'
                health_form = Health_Form(instance=h[0])
        return render(request, 'health_punch.html', locals())


    # 接受表单信息
    if request.method == 'POST':
        tips = None
        # print(request.POST)
        # 对数据进行清洗
        try:
            temperature = temperature_validate(request.POST.get('temperature', ''))
        except ValueError:
            tips = '请输入正确的温度'
            return render(request, 'health_punch.html', locals())

        health = Health_Form(request.POST)
        if health.is_valid():
            temperature = health.cleaned_data['temperature']
            print(temperature)
            health_db = health.save(commit=False)
            health_db.id_num_id = id_num
            health_db.datetime = timezone.localtime()
            health_db.save()
        h = Health.objects.order_by('-datetime')[0]
        health_form = Health_Form(instance=h)
        tips = '您已完成今日打卡'
        return render(request, 'health_punch.html', locals())


def isolate_report(request):
    username = request.user.username
    id_num = Person.objects.get(id=username).id
    return render(request, 'Isolate_report.html', locals())


def appointment_time(request):
    return render(request, 'Appointment_Time.html')


def isolate_search(request):
    return render(request, 'isolate_search.html')


def report_success(request):
    return render(request, 'report_success.html')
