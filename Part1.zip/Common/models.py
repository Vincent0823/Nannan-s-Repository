from django.contrib.auth.models import AbstractUser
from django.db import models


# 级别表
class Level(models.Model):
    id = models.BigIntegerField(verbose_name="级别编号", primary_key=True)
    level = models.CharField(max_length=4, verbose_name="级别名")

    def __str__(self):
        return self.level

    class Meta:
        verbose_name = '级别'
        verbose_name_plural = '级别信息'


# 国家表
class Country(models.Model):
    id = models.CharField(max_length=4, verbose_name="国家代码", primary_key=True)
    name = models.CharField(max_length=100, verbose_name="国家名")

    def __str__(self):
        return self.name

    class Meta:
        verbose_name = '国家'
        verbose_name_plural = '国家'


# 地区表
class Region(models.Model):
    id = models.CharField(max_length=20, verbose_name='地区编号', primary_key=True)
    parent_id = models.CharField(max_length=20, verbose_name='上级行政单位')
    name = models.CharField(max_length=30, verbose_name='名称')
    MergerName = models.CharField(max_length=200, verbose_name='合并名称')
    ShortName = models.CharField(max_length=20, verbose_name='简称')
    level = models.ForeignKey(Level, verbose_name="级别", on_delete=models.PROTECT, db_index=True)
    CityCode = models.CharField(max_length=10, verbose_name='所属城市编号', null=True)

    def __str__(self):
        return self.MergerName

    class Meta:
        verbose_name = '地区'
        verbose_name_plural = '地区'


# 交通种类
class TraceType(models.Model):
    id = models.CharField(max_length=2, verbose_name="交通类型编号", primary_key=True)
    name = models.CharField(max_length=50, verbose_name="交通类型")

    def __str__(self):
        return self.name

    class Meta:
        verbose_name = '交通种类'
        verbose_name_plural = '交通种类'


# 班次表
class Schedule(models.Model):
    traffic_type = models.ForeignKey(TraceType, verbose_name='交通种类', on_delete=models.PROTECT)
    id = models.CharField(max_length=15, verbose_name='班次', primary_key=True)
    company = models.CharField(max_length=30, verbose_name='所属公司')
    trace = models.CharField(max_length=2000, verbose_name='经停站点')
    arrive_time = models.CharField(max_length=2000, verbose_name='到达时间')

    def __str__(self):
        return self.id

    class Meta:
        verbose_name = '班次'
        verbose_name_plural = '班次'


# 角色类型表
class Role(models.Model):
    id = models.IntegerField(verbose_name="角色编号", primary_key=True)
    role = models.CharField(max_length=20, verbose_name="角色名")

    def __str__(self):
        return self.role

    class Meta:
        verbose_name = '用户角色'
        verbose_name_plural = '用户角色'


# 用户表
class User(AbstractUser):
    is_dcc = models.BooleanField(verbose_name='疾控中心状态', default=0)
    is_isp = models.BooleanField(verbose_name='隔离点状态', default=0)
    is_wjw = models.BooleanField(verbose_name='卫健委状态', default=0)

    def __str__(self):
        return self.username

    class Meta:
        verbose_name = '用户'
        verbose_name_plural = '用户'


# 信息来源类型
class SourceType(models.Model):
    id = models.CharField(max_length=8, verbose_name="信息来源编码", primary_key=True)
    type = models.CharField(max_length=10, verbose_name="信息来源类型")

    def __str__(self):
        return self.type

    class Meta:
        verbose_name = '信息来源'
        verbose_name_plural = '信息来源信息'
