import xadmin
from xadmin import views
from .models import *
from django.contrib.auth import get_user_model


# 设置全局变量
class GlobalSetting(object):
    site_header = '疫情管理信息系统'
    site_title = "疫情管理信息系统"
    site_footer = "疫情管理信息系统开发团队"
    menu_style = 'accordion'

    # menu_style = "accordion" ＃ 左侧选项列表出现拉伸效果，可折叠


xadmin.site.register(views.CommAdminView, GlobalSetting)


# # 自选主题样式
# class BaseSetting(object):
#     enable_themes = True
#     use_bootswatch = True
#
#
# xadmin.site.register(views.BaseAdminView, BaseSetting)


# 设置Level的Admin
class LevelAdmin(object):
    list_display = ['id', 'level']
    list_filter = ['id', 'level']
    search_fields = ['level']
    ordering = ['id']


xadmin.site.register(Level, LevelAdmin)


# 设置Country的Admin
class CountryAdmin(object):
    list_display = ['id', 'name']
    list_filter = ['name']
    search_fields = ['name']
    ordering = ['id']
    show_detail_fields = ['name']


xadmin.site.register(Country, CountryAdmin)


# 设置Region的Admin
class RegionAdmin(object):
    list_display = ['id', 'parent_id', 'name', 'MergerName', 'ShortName',
                    'level', 'CityCode']
    list_filter = ['parent_id']
    search_fields = ['id', 'parent_id', 'name', 'ShortName', 'level', 'CityCode']
    ordering = ['id']


xadmin.site.register(Region, RegionAdmin)


# 设置交通种类的Admin
class TraceTypeAdmin(object):
    list_display = ['id', 'name']
    search_fields = ['id', 'name']


xadmin.site.register(TraceType, TraceTypeAdmin)


# 设置班次表的Admin
class ScheduleAdmin(object):
    list_display = ['traffic_type', 'id', 'company', 'trace', 'arrive_time']


# xadmin.site.register(Schedule, ScheduleAdmin)


# 角色类型的Admin
class RoleAdmin(object):
    list_display = ['id', 'role']


xadmin.site.register(Role, RoleAdmin)


# 用户的Admin
class UserAdmin(object):
    list_display = ['username', 'is_staff', 'is_common', 'is_confirmed', 'is_contact',
                    'is_disease_control', 'is_superuser', 'is_active']
    list_filter = ['is_staff', 'is_common', 'is_active', 'is_confirmed', 'is_contact',
                   'is_disease_control', 'is_superuser', 'is_active']


# xadmin.site.unregister(get_user_model())
# xadmin.site.register(get_user_model(), UserAdmin)


# 信息来源类型
class SourceTypeAdmin(object):
    list_display = ['id', 'type']
    list_search = ['id', 'type']


xadmin.site.register(SourceType, SourceTypeAdmin)
