import xadmin
from xadmin import views
from .models import *
from django.db.models import Q
import sys
sys.path.append('..')
from Isolate.models import *


# HealthType的Admin
class HealthTypeAdmin(object):
    list_display = ['type']
    search_fields = ['type', 'id']
    ordering = ['id']


xadmin.site.register(HealthType, HealthTypeAdmin)


# DCC的Admin
class DCCAdmin(object):
    list_display = ['name', 'region', 'level']
    list_filter = ['level', 'region']
    search_fields = ['region', 'name', 'level']
    ordering = ['region', 'level']
    refresh_times = [3, 5]

    # 设置显示结果  （显示自己和下辖的疾控中心）
    def queryset(self):
        qs = super(DCCAdmin, self).queryset()
        if self.request.user.is_superuser:
            return qs
        elif self.request.user.is_dcc:
            user = self.request.user.dcc_set.values()[0]
            # 得到用户细节表之后即可实现层级过滤
            region = user['region_id']
            level = user['level_id']
            target = Region.objects.filter((Q(level_id__gt=level) & Q(id__startswith=region[:level*2])) | Q(id=region)).values('id')
            target = [i['id'] for i in target]
            qs = qs.filter(region_id__in=target)
            return qs

    def get_readonly_fields(self):
        if self.request.user.is_superuser:
            return []
        elif self.request.user.is_dcc:
            return ['system_id', 'name', 'region', 'level']


xadmin.site.register(DCC, DCCAdmin)


# Confirmed的Admin
# 反向连接表 - 待处理
class ContactInline(object):
    model = Contact
    # extar = 1


class ConfirmedQuarantineProcessingInline(object):
    model = ConfirmedQuarantineProcessing
    # extar = 1


# admin
class ConfirmedAdmin(object):
    data_charts = {
        "user_count": {'title': u"确诊数量", "x-field": "confirmed_date", "y-field": ("count", ),
                       "order": ('date',)},
    }
    list_display = ['person', 'dcc', 'health_type',
                    'confirmed_date', 'death_date', 'recover_date']
    list_filter = ['dcc', 'health_type', ]
    search_fields = ['person', 'dcc', 'health_type',
                     'confirmed_date', 'death_date', 'recover_date']
    ordering = ['confirmed_date']
    relfield_style = 'fk_ajax'
    refresh_times = [3, 5]
    inlines = [ConfirmedQuarantineProcessingInline, ContactInline, ]

    # # 设置只读字段
    # def get_readonly_fields(self):
    #     if self.request.user.is_superuser:
    #         return []
    #     elif self.request.user.is_dcc:
    #         return ['dcc']

    # 设置显示结果  （显示自己和下辖疾控中心上报的确诊患者）
    def queryset(self):
        qs = super(ConfirmedAdmin, self).queryset()
        if self.request.user.is_superuser:
            return qs
        elif self.request.user.is_dcc:
            user = self.request.user.dcc_set.values()[0]
            # 得到用户细节表之后即可实现层级过滤
            region = user['region_id']
            level = user['level_id']
            target = Region.objects.filter((Q(level_id__gt=level) & Q(id__startswith=region[:level*2])) | Q(id=region)).values('id')
            target = [i['id'] for i in target]
            qs = qs.filter(dcc__region_id__in=target)
            return qs

    # 设置外键的可选值
    def formfield_for_dbfield(self, db_field, **kwargs):
        if db_field.name == 'dcc':
            if not self.request.user.is_superuser:
                kwargs["queryset"] = DCC.objects.filter(region_id=self.request.user.username)
        return super(ConfirmedAdmin, self).formfield_for_dbfield(db_field, **kwargs)

    # 重写表单
    # def instance_forms(self):
    #     super().instance_forms()
    #     if not self.org_obj:
    #         self.form_obj.initial['dcc'] = self.request.user
    #         print(self.request.user)

    # 保存时调用的函数
    def save_models(self):
        obj = self.new_obj
        person_id = obj.id  # 得到确诊患者的id，插入到隔离点中
        obj.save()
        # TODO : 插入到隔离点

    # 删除时调用的函数
    def delete_models(self, obj):
        obj.delete()


xadmin.site.register(Confirmed, ConfirmedAdmin)


class ContactAdmin(object):
    list_display = ['contacted', 'dcc', 'contact', 'region', 'position',
                    'contact_date']
    list_filter = ['region', 'dcc']
    search_fields = ['dcc', 'contacted', 'contact', 'region', 'position',
                     'contact_date']
    ordering = ['contact_date']
    relfield_style = 'fk_ajax'
    refresh_times = [3, 5]

    # 设置显示结果  （显示自己和下辖疾控中心上报的密切接触者）
    def queryset(self):
        qs = super(ContactAdmin, self).queryset()
        if self.request.user.is_superuser:
            return qs
        elif self.request.user.is_dcc:
            user = self.request.user.dcc_set.values()[0]
            # 得到用户细节表之后即可实现层级过滤
            region = user['region_id']
            level = user['level_id']
            target = Region.objects.filter((Q(level_id__gt=level) & Q(id__startswith=region[:level*2])) | Q(id=region)).values('id')
            target = [i['id'] for i in target]
            qs = qs.filter(dcc__region_id__in=target)
            return qs

    # 设置外键的可选值
    def formfield_for_dbfield(self, db_field, **kwargs):
        if db_field.name == 'dcc':
            if not self.request.user.is_superuser:
                kwargs["queryset"] = DCC.objects.filter(region_id=self.request.user.username)
        return super(ContactAdmin, self).formfield_for_dbfield(db_field, **kwargs)

    # 保存时调用的函数
    def save_models(self):
        obj = self.new_obj
        person_id = obj.id  # 得到确诊患者的id，插入到隔离点中
        obj.save()
        # TODO : 插入到隔离点

    # 删除时调用的函数
    def delete_models(self, obj):
        obj.delete()


xadmin.site.register(Contact, ContactAdmin)
