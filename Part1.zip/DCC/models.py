from django.db import models
import sys
sys.path.append('..')
from Common.models import *
from Person.models import *


# 当前状况
class HealthType(models.Model):
    id = models.IntegerField(verbose_name='健康状况编码', primary_key=True)
    type = models.CharField(max_length=3, verbose_name="健康状况")

    def __str__(self):
        return self.type

    class Meta:
        verbose_name = '健康状况'
        verbose_name_plural = '健康状况'


# 疾控中心表
class DCC(models.Model):
    system_id = models.ForeignKey(User, verbose_name="系统编号", on_delete=models.PROTECT)

    # 基本信息
    level = models.ForeignKey(Level, verbose_name="疾控中心级别", on_delete=models.PROTECT)
    region = models.ForeignKey(Region, verbose_name="所属地区", related_name="center_region",
                               on_delete=models.PROTECT, null=True)
    name = models.CharField(max_length=255, verbose_name="疾控中心名")

    # 创建疾控中心
    """
    python manage.py shell
    from DCC.models import *
    DCC.create_disease_control_center(DCC, '合肥市疾控中心', '340100', 2)
    DCC.create_disease_control_center(DCC, '瑶海区疾控中心', '340102', 3)
    DCC.create_disease_control_center(DCC, '庐阳区疾控中心', '340103', 3)
    """
    def create_disease_control_center(self, name, region, level):
        User.objects.create_user(username=region, password='123456', is_staff=True, is_dcc=True)
        user = User.objects.get(username=region)
        user.groups.add(1)  # 将其group设置为疾控中心
        system_id = user.id
        self.objects.create(system_id_id=system_id, region_id=region, name=name, level_id=level)

    def __str__(self):
        return self.name

    class Meta:
        verbose_name = '疾控中心'
        verbose_name_plural = '疾控中心信息'


# 确诊人员表
class Confirmed(models.Model):
    # id = models.IntegerField(verbose_name='确诊人员编号', primary_key=True)
    dcc = models.ForeignKey(DCC, verbose_name="报告的疾控中心", on_delete=models.PROTECT)
    person = models.ForeignKey(Person, verbose_name="确诊人员", on_delete=models.PROTECT)
    health_type = models.ForeignKey(HealthType, verbose_name="当前状态", on_delete=models.PROTECT)

    confirmed_date = models.DateTimeField(verbose_name="报告时间")
    death_date = models.DateTimeField(verbose_name="死亡时间", null=True, blank=True)
    recover_date = models.DateTimeField(verbose_name="康复时间", null=True, blank=True)
    count = models.IntegerField(verbose_name='test', default=22)

    def __str__(self):
        return Person.objects.get(id=self.person_id).name

    class Meta:
        verbose_name = '确诊人员'
        verbose_name_plural = '确诊人员信息'


# 密切接触者表
class Contact(models.Model):
    dcc = models.ForeignKey(DCC, verbose_name="报告的疾控中心", on_delete=models.PROTECT)
    contacted = models.ForeignKey(Person, verbose_name="密切接触者",
                                  related_name="contacted", on_delete=models.PROTECT)
    contact = models.ForeignKey(Confirmed, verbose_name="接触人", on_delete=models.PROTECT)
    region = models.ForeignKey(Region, verbose_name='接触地所在区划',
                               related_name="contact_region", on_delete=models.PROTECT)
    position = models.CharField(max_length=200, verbose_name='具体位置')
    contact_date = models.DateTimeField(verbose_name='接触时间')

    def __str__(self):
        return "-".join([str(self.contacted), str(self.contact)])

    class Meta:
        verbose_name = '密切接触者'
        verbose_name_plural = '密切接触者信息'
