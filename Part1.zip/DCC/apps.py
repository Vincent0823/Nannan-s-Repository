from django.apps import AppConfig


class DccConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'DCC'
    verbose_name = '疾控中心'
