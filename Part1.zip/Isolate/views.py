from django.shortcuts import render, HttpResponse, redirect
from .models import *
from django.utils import timezone
from .form import *


def receive(request, record_id):
    # 得到要处理的记录
    record = ConfirmedQuarantineProcessing.objects.get(id=record_id)
    # 获取所属隔离点信息
    isolator = record.isolator
    isp = record.isolated_point
    # 得到对应的Person
    person = Confirmed.objects.get(id=record.isolator_id).person_id
    print(person)
    # 将要处理的人员添加到管理人员界面中
    QuarantineManagement.objects.create(isolator_id=person, isolated_point=isp,
                                        receiving_time=timezone.localtime(), reason='新冠确诊')
    # 设置处理结果
    record.finished = True
    record.save()
    return redirect('../')


def transmit(request, record_id):
    # 返回供选择的表单
    record = ConfirmedQuarantineProcessing.objects.get(id=record_id)
    form_obj = CQPForm(instance=record)
    if request.method == 'GET':
        # 将要转交的人员添加到指定的隔离点下
        return render(request, 'select_dcc.html', locals())
    else:
        # 得到arrive_time
        if request.POST['arrive_time'] == '':
            arrive_time = record.arrive_time
        else:
            arrive_time = request.POST['arrive_time'] + ' 00:00'
        # 设置转交结果
        ConfirmedQuarantineProcessing.objects.create(
            isolator_id=record.isolator.id,
            isolated_point_id=request.POST['isolated_point'],
            finished=False,
            transmitted=False,
            commit_time=record.commit_time,
            arrive_time=arrive_time,
        )
        # 更改修改状态
        record.transmitted = True
        record.save()
        return redirect('../')
