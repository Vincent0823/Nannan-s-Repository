from django import forms
from .models import *
import sys


# 选择转交地点的表单
class CQPForm(forms.ModelForm):
    class Meta:
        model = ConfirmedQuarantineProcessing
        fields = ['isolated_point', 'commit_time', 'arrive_time']
        labels = {
            # 'isolator': '隔离人员编号',
            'isolated_point': '转交的隔离点',
            'commit_time': '隔离发起时间',
            'arrive_time': '预计到达时间',
        }
        widgets = {
            # 'isolator': forms.widgets.TextInput(attrs={'disabled': 'True'}),
            'commit_time': forms.widgets.DateTimeInput(attrs={'disabled': 'True'}),
            'arrive_time': forms.widgets.DateTimeInput(attrs={'type': 'date'}),
        }
