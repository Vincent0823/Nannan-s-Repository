from django.apps import AppConfig


class IsolateConfig(AppConfig):
    name = 'Isolate'
    verbose_name = '隔离点'
