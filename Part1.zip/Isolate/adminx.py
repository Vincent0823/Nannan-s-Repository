import xadmin
from django.db.models import Q
from xadmin import views
from .models import *


# IsolatedPoint的Admin
class ISPAdmin(object):
    list_display = ['name', 'region', 'address_detail', 'level']
    list_filter = ['level', 'region']
    search_fields = ['name', 'region', 'address_detail', 'level']
    ordering = ['region', 'level']
    list_editable = ['address_detail']
    relfield_style = 'fk_ajax'
    refresh_times = [3, 5]

    # 设置显示结果
    def queryset(self):
        qs = super(ISPAdmin, self).queryset()
        if self.request.user.is_superuser:
            return qs
        elif self.request.user.is_dcc:  # 疾控中心能够看到下辖的所有隔离点
            user = self.request.user.dcc_set.values()[0]
            # 实现层级过滤
            region = user['region_id']
            level = user['level_id']
            target = Region.objects.filter(Q(level_id__gte=level) & Q(id__startswith=region[:level*2])).values('id')
            target = [i['id'] for i in target]
            qs = qs.filter(region_id__in=target)
            return qs
        elif self.request.user.is_isp:  # 隔离点只能看到自己的信息
            user = self.request.user.isp_set.values()[0]
            isp_id = user['id']
            qs = qs.filter(id=isp_id)
            return qs
        else:
            pass

    def get_readonly_fields(self):
        if self.request.user.is_superuser:
            return []
        elif self.request.user.is_isp:
            return ['system_id', 'name', 'region', 'level']
        elif self.request.user.is_dcc:
            return ['system_id', 'region', 'level']


xadmin.site.register(ISP, ISPAdmin)


# 确诊待处理的Admin
class ConfirmedQuarantineProcessingAdmin(object):
    list_display = ['isolator', 'isolated_point', 'commit_time', 'deal', 'transmit', ]
    list_filter = ['isolated_point', 'finished', ]
    search_fields = ['isolator', 'isolated_point', 'finished', 'commit_time',
                     'arrive_time']
    ordering = ['finished', 'commit_time', 'transmitted']
    relfield_style = 'fk_ajax'
    refresh_times = [3, 5]
    # list_editable = ['finished']

    # 设置处理按钮
    def deal(self, request):
        # 接收该人员并刷新页面
        from django.utils.safestring import mark_safe
        if request.finished:
            return mark_safe("<font>已接收</font>")
        elif request.transmitted:
            return mark_safe("<font></font>")
        else:
            return mark_safe("<a href='receive/%s'>接收</a>" % request.id)

    deal.short_description = "接收"

    # 设置转交按钮
    def transmit(self, request):
        # 转交该人员，完成后刷新页面
        from django.utils.safestring import mark_safe
        if request.transmitted:
            return mark_safe("<font>已转交</font>")
        elif request.finished:
            return mark_safe("<font></font>")
        else:
            return mark_safe("<a href='transmit/%s'>转交</a>" % request.id)

    transmit.short_description = "转交"

    # 设置显示结果
    def queryset(self):
        qs = super(ConfirmedQuarantineProcessingAdmin, self).queryset()
        if self.request.user.is_superuser:
            return qs
        elif self.request.user.is_dcc:  # 疾控中心能够看到下辖的所有隔离点
            user = self.request.user.dcc_set.values()[0]
            # 实现层级过滤
            region = user['region_id']
            level = user['level_id']
            target = Region.objects.filter(Q(level_id__gte=level) & Q(id__startswith=region[:level * 2])).values('id')
            target = [i['id'] for i in target]
            qs = qs.filter(isolated_point__region__in=target)
            return qs
        elif self.request.user.is_isp:  # 隔离点只能看到自己的信息
            user = self.request.user.isp_set.values()[0]
            isp_id = user['id']
            print(isp_id)
            qs = qs.filter(isolated_point_id=isp_id)
            return qs
        else:
            pass

    # 设置外键的可选值
    def formfield_for_dbfield(self, db_field, **kwargs):
        if db_field.name == 'isolated_point':
            if self.request.user.is_dcc:  # 疾控中心可以看到下属隔离点的信息
                user = self.request.user.dcc_set.values()[0]
                # 得到用户细节表之后即可实现层级过滤
                region = user['region_id']
                level = user['level_id']
                kwargs["queryset"] = ISP.objects.filter(Q(Q(level_id__gte=level) & Q(region__id__startswith=region[:level*2])))
            if self.request.user.is_isp:  # 隔离点只能看到自己的信息
                username = self.request.user.username
                kwargs["queryset"] = ISP.objects.filter(system_id__username=username)
        return super(ConfirmedQuarantineProcessingAdmin, self).formfield_for_dbfield(db_field, **kwargs)

    def get_readonly_fields(self):
        print(self.request)
        if self.request.user.is_superuser:
            return []
        else:
            # 如果已经处理，则不能修改负责的隔离点
            return ['isolator', 'isolated_point', 'commit_time', 'finished', 'transmitted']


xadmin.site.register(ConfirmedQuarantineProcessing, ConfirmedQuarantineProcessingAdmin)


# 密切接触待处理的Admin
class ContactQuarantineProcessingAdmin(object):
    list_display = ['isolator', 'isolated_point', 'commit_time', 'finished', 'reason']
    list_filter = ['isolated_point', 'finished']
    search_fields = ['isolator', 'isolated_point', 'finished', 'commit_time',
                     'arrive_time', 'reason']
    ordering = ['finished', 'commit_time']
    relfield_style = 'fk_ajax'
    refresh_times = [3, 5]
    list_editable = ['finished']

    # 设置显示结果
    def queryset(self):
        qs = super(ContactQuarantineProcessingAdmin, self).queryset()
        if self.request.user.is_superuser:
            return qs
        elif self.request.user.is_dcc:  # 疾控中心能够看到下辖的所有隔离点
            user = self.request.user.dcc_set.values()[0]
            # 实现层级过滤
            region = user['region_id']
            level = user['level_id']
            target = Region.objects.filter(Q(level_id__gte=level) & Q(id__startswith=region[:level * 2])).values('id')
            target = [i['id'] for i in target]
            qs = qs.filter(isolated_point__region__in=target)
            return qs
        elif self.request.user.is_isp:  # 隔离点只能看到自己的信息
            user = self.request.user.isp_set.values()[0]
            isp_id = user['id']
            print(isp_id)
            qs = qs.filter(isolated_point_id=isp_id)
            return qs
        else:
            pass

    # 设置外键的可选值
    def formfield_for_dbfield(self, db_field, **kwargs):
        if db_field.name == 'isolated_point':
            if self.request.user.is_dcc:  # 疾控中心可以看到下属隔离点的信息
                user = self.request.user.dcc_set.values()[0]
                # 得到用户细节表之后即可实现层级过滤
                region = user['region_id']
                level = user['level_id']
                kwargs["queryset"] = ISP.objects.filter(Q(Q(level_id__gte=level) & Q(region__id__startswith=region[:level*2])))
            if self.request.user.is_isp:  # 隔离点只能看到自己的信息
                username = self.request.user.username
                kwargs["queryset"] = ISP.objects.filter(system_id__username=username)
        return super(ContactQuarantineProcessingAdmin, self).formfield_for_dbfield(db_field, **kwargs)

    def get_readonly_fields(self):
        if self.request.user.is_superuser:
            return []
        else:
            return ['finished']


xadmin.site.register(ContactQuarantineProcessing, ContactQuarantineProcessingAdmin)


# 新到待处理的Admin
class ComerQuarantineProcessingAdmin(object):
    list_display = ['isolator', 'isolated_point', 'commit_time', 'finished', 'reason']
    list_filter = ['isolated_point', 'finished']
    search_fields = ['isolator', 'isolated_point', 'finished', 'commit_time',
                     'arrive_time', 'reason']
    ordering = ['finished', 'commit_time']
    relfield_style = 'fk_ajax'
    refresh_times = [3, 5]

    # 设置显示结果
    def queryset(self):
        qs = super(ComerQuarantineProcessingAdmin, self).queryset()
        if self.request.user.is_superuser:
            return qs
        elif self.request.user.is_dcc:  # 疾控中心能够看到下辖的所有隔离点
            user = self.request.user.dcc_set.values()[0]
            # 实现层级过滤
            region = user['region_id']
            level = user['level_id']
            target = Region.objects.filter(Q(level_id__gte=level) & Q(id__startswith=region[:level * 2])).values('id')
            target = [i['id'] for i in target]
            qs = qs.filter(isolated_point__region__in=target)
            return qs
        elif self.request.user.is_isp:  # 隔离点只能看到自己的信息
            user = self.request.user.isp_set.values()[0]
            isp_id = user['id']
            print(isp_id)
            qs = qs.filter(isolated_point_id=isp_id)
            return qs
        else:
            pass

    # 设置外键的可选值
    def formfield_for_dbfield(self, db_field, **kwargs):
        if db_field.name == 'isolated_point':
            if self.request.user.is_dcc:  # 疾控中心可以看到下属隔离点的信息
                user = self.request.user.dcc_set.values()[0]
                # 得到用户细节表之后即可实现层级过滤
                region = user['region_id']
                level = user['level_id']
                kwargs["queryset"] = ISP.objects.filter(Q(Q(level_id__gte=level) & Q(region__id__startswith=region[:level*2])))
            if self.request.user.is_isp:  # 隔离点只能看到自己的信息
                username = self.request.user.username
                kwargs["queryset"] = ISP.objects.filter(system_id__username=username)
        return super(ComerQuarantineProcessingAdmin, self).formfield_for_dbfield(db_field, **kwargs)


xadmin.site.register(ComerQuarantineProcessing, ComerQuarantineProcessingAdmin)


# 确诊待处理的Admin
class QuarantineManagementAdmin(object):
    # TODO : 添加转交和结束
    list_display = ['isolator', 'isolated_point', 'receiving_time', 'leaving_time', ]
    list_filter = ['isolated_point', 'finished', 'transmitted', 'receiving_time', 'leaving_time', ]
    search_fields = ['isolator', 'isolated_point', 'finished', 'transmitted', 'receiving_time', 'leaving_time', ]
    ordering = ['finished', 'transmitted', 'receiving_time']
    relfield_style = 'fk_ajax'
    refresh_times = [3, 5]


xadmin.site.register(QuarantineManagement, QuarantineManagementAdmin)
