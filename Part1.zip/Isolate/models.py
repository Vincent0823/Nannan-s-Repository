from django.db import models
import sys
sys.path.append('..')
from DCC.models import *
from Common.models import *


# 隔离点信息
class ISP(models.Model):
    system_id = models.ForeignKey(User, verbose_name="系统编号", on_delete=models.PROTECT)

    # 基本信息
    level = models.ForeignKey(Level, verbose_name="隔离点级别", on_delete=models.PROTECT)
    region = models.ForeignKey(Region, verbose_name='所在区划', on_delete=models.PROTECT)
    address_detail = models.CharField(max_length=200, verbose_name='详细地址', null=True, blank=True)

    name = models.CharField(max_length=255, verbose_name="隔离点名称")

    # 创建隔离点
    """
        python manage.py shell
        from Isolate.models import *
        ISP.create_isolated_point(ISP, '安徽医科大学第一附属医院', '340000', '01', 1)
        ISP.create_isolated_point(ISP, '安徽医科大学第二附属医院', '340000', '02', 1)
        ISP.create_isolated_point(ISP, '合肥市滨湖医院', '340100', '01', 2)
        ISP.create_isolated_point(ISP, '合肥市第二人民医院', '340100', '02', 2)
    """
    def create_isolated_point(self, name, region, no, level):
        User.objects.create_user(username=region + no, password='123456', is_staff=True, is_isp=True)
        user = User.objects.get(username=region + no)
        user.groups.add(2)  # 将其group设置为隔离点
        system_id = user.id
        self.objects.create(system_id_id=system_id, region_id=region, name=name, level_id=level)

    def __str__(self):
        return self.name

    class Meta:
        verbose_name = '隔离点'
        verbose_name_plural = '隔离点信息'


# 待处理确诊人员隔离信息
class ConfirmedQuarantineProcessing(models.Model):
    isolator = models.ForeignKey(Confirmed, verbose_name='隔离人员', on_delete=models.PROTECT)
    isolated_point = models.ForeignKey(ISP, verbose_name='负责的隔离点', on_delete=models.PROTECT)
    finished = models.BooleanField(verbose_name='处理', default=False)
    transmitted = models.BooleanField(verbose_name='转交', default=False)
    commit_time = models.DateTimeField(verbose_name='发起时间')
    arrive_time = models.DateTimeField(verbose_name='预计到达时间', null=True, blank=True)

    class Meta:
        verbose_name = '待处理确诊隔离'
        verbose_name_plural = '待处理确诊隔离'

    def __str__(self):
        return "-".join([str(self.isolator), str(self.isolated_point)])


# 待处理密切接触人员隔离信息
class ContactQuarantineProcessing(models.Model):
    isolator = models.ForeignKey(Contact, verbose_name='隔离人员', on_delete=models.PROTECT)
    isolated_point = models.ForeignKey(ISP, verbose_name='负责的隔离点', on_delete=models.PROTECT)
    finished = models.BooleanField(verbose_name='处理', default=False)
    transmitted = models.BooleanField(verbose_name='转交', default=False)
    commit_time = models.DateTimeField(verbose_name='发起时间')
    arrive_time = models.DateTimeField(verbose_name='预计到达时间', null=True, blank=True)
    reason = models.TextField(verbose_name='隔离原因')

    class Meta:
        verbose_name = '待处理密切接触隔离'
        verbose_name_plural = '待处理密切接触隔离'

    def __str__(self):
        return "-".join([str(self.isolator), str(self.isolated_point)])


# 待处理新到人员隔离信息
class ComerQuarantineProcessing(models.Model):
    isolator = models.ForeignKey(Person, verbose_name='隔离人员', on_delete=models.PROTECT)
    isolated_point = models.ForeignKey(ISP, verbose_name='负责的隔离点', on_delete=models.PROTECT)
    finished = models.BooleanField(verbose_name='处理', default=False)
    transmitted = models.BooleanField(verbose_name='转交', default=False)
    commit_time = models.DateTimeField(verbose_name='发起时间')
    arrive_time = models.DateTimeField(verbose_name='预计到达时间', null=True, blank=True)
    reason = models.TextField(verbose_name='隔离原因')

    class Meta:
        verbose_name = '待处理新到隔离'
        verbose_name_plural = '待处理新到隔离'

    def __str__(self):
        return "-".join([str(self.isolator), str(self.isolated_point)])


# 隔离人员管理信息
class QuarantineManagement(models.Model):
    isolator = models.ForeignKey(Person, verbose_name='隔离人员', on_delete=models.PROTECT)
    isolated_point = models.ForeignKey(ISP, verbose_name='负责的隔离点', on_delete=models.PROTECT)
    finished = models.BooleanField(verbose_name='隔离结束', default=False)
    transmitted = models.BooleanField(verbose_name='转交', default=False)
    receiving_time = models.DateTimeField(verbose_name='接收时间')
    leaving_time = models.DateTimeField(verbose_name='离开时间', null=True, blank=True)
    reason = models.TextField(verbose_name='隔离原因', null=True, blank=True)

    class Meta:
        verbose_name = '隔离人员'
        verbose_name_plural = '隔离人员管理信息'

    def __str__(self):
        return self.isolator_id


# 隔离人员健康状况
class QuarantineHealthInfo(models.Model):
    isolator = models.ForeignKey(QuarantineManagement, verbose_name='隔离人员', on_delete=models.PROTECT)
    temperature = models.CharField(max_length=5, verbose_name='体温')
    symptoms = models.CharField(max_length=200, verbose_name='当前症状', null=True)

    class Meta:
        verbose_name = '隔离人员健康状况'
        verbose_name_plural = '隔离人员健康状况'

    def __str__(self):
        return self.isolator_id
